package com.Heladeria_Ojari_Back.backend_heladeria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendHeladeriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
