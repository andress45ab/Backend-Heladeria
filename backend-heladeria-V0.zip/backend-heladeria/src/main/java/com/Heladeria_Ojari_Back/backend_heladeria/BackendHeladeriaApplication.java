package com.Heladeria_Ojari_Back.backend_heladeria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendHeladeriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendHeladeriaApplication.class, args);
	}

}
